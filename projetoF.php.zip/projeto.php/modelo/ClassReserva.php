<?php
Class Reserva{
   private $id; 
   private $dataEntrada;
   private $dataSaida;
   private $status;
    
   public function getId(){
    return $this->id;
   }
   public function getDataEntrada(){
    return $this->dataEntrada;
   }
   public function getDataSaida(){
    return $this->dataSaida;
   }
   public function getStatus(){
    return $this->status;
   }
   public function setId($id){
    $this->id = $id;
   }
   public function setDataEntrada($dataEntrada){
    $this->dataEntrada = $dataEntrada;
   }
   public function setDataSaida($dataSaida){
    $this->dataSaida = $dataSaida;
   }
   public function setStatus($status){
    $this->status = $status;
   }

}


?>