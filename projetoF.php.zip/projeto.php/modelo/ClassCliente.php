<?php

Class Cliente{
   private $clienteId;
   private $nome;
   private $email;
   private $telefone;
   private $cpf;

   public function getClienteId(){
    return $this->clienteId;
   }
   
   public function getNome(){
    return $this->nome;
   }
   public function getEmail(){
    return $this->email;
   }
   public function getTelefone(){
    return $this->telefone;
   }
   public function getCpf(){
    return $this->cpf;
   }
   public function setClienteId($clienteId){
    $this->clienteId = $clienteId;
   }

   public function setNome($nome){
    $this-> nome = $nome;
   }
   public function setEmail($email){
    $this->email = $email;
   }
   public function setTelefone($telefone){
    $this->telefone = $telefone;
   }
   public function setCpf($cpf){
    $this->cpf = $cpf;
   }




}




?>