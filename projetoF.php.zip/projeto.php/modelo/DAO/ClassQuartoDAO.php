<?php
require_once 'Conexao.php';

Class ClassQuartoDao{
  public static function cadastrarQuarto(ClassQuarto $cadQuarto){
   
    try{
        $pdo = Conexao::getInstance();
        $sql = 'INSERT INTO quarto values (?,?,?)';
          $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $cadQuarto->getTipoDeQuarto());
            $stmt->bindValue(2, $cadQuarto->getCapacidade());
            $stmt->bindValue(3,$cadQuarto->getPrecoPorNoite());
            $stmt->execute();
    }catch(PDOException $exc){
        echo $exc-getMessage();
    }
}

public static function listarQuarto(){
   try{
        $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM quarto order by preco_por_noite asc";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $quarto = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $quarto;
   }catch(PDOException $exc){
    echo $exc->getMessage();
   }
 }
public static function excluirQuarto($quartoId){
    
    try{ 
    $pdo = Conexao::getInstance();
    $sql = 'DELETE FROM quarto WHERE quartos_id =: quartos_id';
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':quartos_id', $quartoId);
            $stmt->execute();
            return TRUE;
      }catch(PDOException $exc){
           echo $exc->getMessage();
      }
    }

     public static function alterarQuarto(ClassQuarto $alterarQuarto){
        try{
            $pdo = Conexao::getInstance();
            $sql = 'UPDATE quarto SET tipoDeQuarto=?, capacidade=?, preco_por_noite=? WHERE quartos_id = ? ';
             $stmt = $pdo->prepare($sql);
             $stmt->bindValue(1,$alterarQuarto->getTipoDeQuarto());
             $stmt->bindValue(2,$alterarQuarto->getCapacidade());
             $stmt->bindValue(3,$alterarQuarto->getPrecoPorNoite());
             $stmt->bindValue(4,$alterarQuarto->getQuartoId());
             $stmt->execute();
             return true;
        }catch(PDOException $exc){
            echo $exc->getMessage();
        }



      }

      public function listarComStatus($data_inicio, $data_fim) {
        $sql = "
            SELECT 
                q.quartos_id,
                q.TipoDeQuarto,
                q.capacidade,
                q.preco_por_noite,
                r.data_entrada,
                r.data_saida,
                r.status AS status_reserva,
                CASE
                    WHEN r.quarto_id IS NOT NULL 
                         AND r.status = 'confirmada'
                         AND r.data_entrada <= :data_fim
                         AND r.data_saida >= :data_inicio
                    THEN 'Ocupado'
                    ELSE 'Disponível'
                END AS status_quarto
            FROM quartos q
            LEFT JOIN reserva r ON q.quartos_id = r.quarto_id 
                                  AND r.status = 'confirmada'
                                  AND r.data_entrada <= :data_fim
                                  AND r.data_saida >= :data_inicio
            ORDER BY q.quartos_id
        ";
        $pdo = Conexao::getInstance();
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':data_inicio', $data_inicio);
        $stmt->bindValue(':data_fim', $data_fim);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

?>