<?php
require_once 'Conexao.php';
 
Class ClassUsuarioDAO{
  //cadstro
public static function cadastrarUsuario(ClassUsuario $cadUser){
   
    try{
        $pdo = Conexao::getInstance();
        $sql = 'INSERT INTO usuario values (?,?,?,?)';
          $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $cadUser->getNomeUsuario());
            $stmt->bindValue(2, $cadUser->getEmailUsuario());
            $stmt->bindValue(3,$cadUser->getSenha());
            $stmt->bindValue(4,$cadUser->getTipo());
            $stmt->execute();
    }catch(PDOException $exc){
        echo $exc-getMessage();
    }
}

 //listar
 public static function listarUsuario(){
   try{
        $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM usuario order by (nome) asc";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $usuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $usuario;
   }catch(PDOException $exc){
    echo $exc->getMessage();
   }
 }

 //excluir

 public static function excluirUsuario($usuarioId){
    
    try{ 
    $pdo = Conexao::getInstance();
    $sql = 'DELETE FROM usuario WHERE usuario_id =: usuario_id';
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':usuario_id', $usuarioId);
            $stmt->execute();
            return TRUE;
      }catch(PDOException $exc){
           echo $exc->getMessage();
      }

      

 }
//alterar

      public static function alterarUsuario(ClassUsuario $alterarUsuario){
        try{
            $pdo = Conexao::getInstance();
            $sql = 'UPDATE usuario SET nome=?, email=? WHERE usuario_id = ? ';
             $stmt = $pdo->prepare($sql);
             $stmt->bindValue(1,$alterarUsuario->getNome());
             $stmt->bindValue(2,$alterarUsuario->getEmail());
             $stmt->bindValue(3,$alterarUsuario->getClienteId());
             $stmt->execute();
             return true;
        }catch(PDOException $exc){
            echo $exc->getMessage();
        }
      }
     public function existeUsuario($usuario) {
        $sql = "SELECT COUNT(*) as total FROM usuario WHERE usuario = :usuario";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':usuario', $usuario);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'] > 0;
    }
}








?>