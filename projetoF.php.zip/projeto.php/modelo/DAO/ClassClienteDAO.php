<?php
require_once 'Conexao.php';
 
Class ClassClienteDAO{
  //cadstro
public static function cadastrarCliente(ClassCliente $cadCliente){
   
    try{
        $pdo = Conexao::getInstance();
        $sql = 'INSERT INTO cliente values (?,?,?,?)';
          $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $cadCliente->getNome());
            $stmt->bindValue(2, $cadCliente->getEmail());
            $stmt->bindValue(3,$cadCliente->getTelefone());
            $stmt->bindValue(4,$cadCliente->getCpf());
            $stmt->execute();
    }catch(PDOException $exc){
        echo $exc-getMessage();
    }
}

 //listar
 public static function listarCliente(){
   try{
        $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM cliente order by (nome) asc";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $cliente = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $cliente;
   }catch(PDOException $exc){
    echo $exc->getMessage();
   }
 }

 //excluir

 public static function excluirCliente($clienteId){
    
    try{ 
    $pdo = Conexao::getInstance();
    $sql = 'DELETE FROM cliente WHERE clientes_id =: clientes_id';
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':clientes_id', $clienteId);
            $stmt->execute();
            return TRUE;
      }catch(PDOException $exc){
           echo $exc->getMessage();
      }

      

 }
//alterar

      public static function alterarCliente(ClassCliente $alterarCliente){
        try{
            $pdo = Conexao::getInstance();
            $sql = 'UPDATE cleinte SET nome=?, email=? WHERE clientes_id = ? ';
             $stmt = $pdo->prepare($sql);
             $stmt->bindValue(1,$alterarCliente->getNome());
             $stmt->bindValue(2,$alterarCliente->getEmail());
             $stmt->bindValue(3,$alterarCliente->getClienteId());
             $stmt->execute();
             return true;
        }catch(PDOException $exc){
            echo $exc->getMessage();
        }



      }

}








?>