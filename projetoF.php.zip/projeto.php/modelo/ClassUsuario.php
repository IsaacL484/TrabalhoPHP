<?php
Class Usuario{
    private $usuarioId;
    private $nomeUsuario;
    private $emailUsuario;
    private $senha;
    private $tipo;

    public function getUsuarioId(){
        return $this->usuarioId;
    }
    public function getNomeUsuario(){
        return $this->nomeUsuario;
    }
    public function getEmailUsuario(){
        return $this->emailUsuario;
    }
    public function getSenha(){
        return $this->senha;
    }
    public function getTipo(){
        return $this->tipo;
    }
    public function setUsuarioId($usuarioId){
        $this->usuarioId = $usuarioId;

    }
    public function setNomeUsuario($nomeUsuario){
        $this->nomeUsuario = $nomeUsuario;
    }
    public function setEmailUsuario($emailUsuario){
        $this->emailUsuario = $emailUsuario;
    }
    public function setSenha($senha){
        $this->senha = $senha;
    }
    public function setTipo($tipo){
        $this->senha = $tipo;
    }


}

?>