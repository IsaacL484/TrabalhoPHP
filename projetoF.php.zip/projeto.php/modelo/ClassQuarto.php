<?php
 Class Quarto{
    private $quartoId;
    private $tipoDeQuarto;
    private $capacidade;
    private $precoPorNoite;

    public function getQuartoId(){
        return $this->quartoId;
    }

    public function getTipoDeQuarto(){
        return $this->tipoDeQuarto;
    }
    public function getCapacidade(){
        return $this->capacidade;
    }
    public function getPrecoPorNoite(){
        return $this->precoPorNoite;
    }
    public function setQuartoId($quartoId){
        $this->quartoId = $quartoId;
    }

    public function setTipoDeQuarto($tdq){
        $this->tipoDeQuarto = $tdq;
    }
    public function setCapacidade($capacidade){
        $this->capacidade = $capacidade;
    }
    public function setPrecoPorNoite($ppn){
        $this->precoPorNoite = $ppn;
    }



 }





?>