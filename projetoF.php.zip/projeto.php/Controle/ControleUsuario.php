<?php
   require_once '../Modelo/ClassUsuario.php';
   require_once '../Modelo/DAO/ClassUsuarioDao.php';

   $id = @$_POST['idex'];
   $nome = @$_POSt['nomeUser'];
   $email = @$_POST ['emailUser'];
   $senha = @$_POST['senhaUser'];
   $tipo = @$_POST['tipoUser'];
   $acao = $_GET['ACAO'];


   $novoUsuario = new ClassUsuario();
   $novoUsuario->setClienteId($id);
   $novoUsuario->setNome($nome);
   $novoUsuario->setEmail($email);
   $novoUsuario->setTelefone($senha);
   $novoUsuario->setCpf($tipo);
  
   $ClassUsuarioDAO = new ClassUsuarioDAO();
     switch($acao){
        case "cadastrarUsuario":
            $usuario = $ClassUsuarioDAO->cadastrarUsuario($novoUsuario);
           if($usuario >=1){
             
           }else{

           }
        break;

        case "alterarUsuario":
            $usuario = $ClassUsuarioDAO->alterarUsuario($novoUsuario);
            if($usuario ==1){

            }else{

            }
            break;

        case "excluirUsuario":
            if (isset($_GET['idex'])) {
            $usuarioId = $_GET['idex'];
            $classUsuarioDAO = new ClassUsuarioDAO();
            $us = $classUsuarioDAO->excluirUsuario($usuarioId);
            if ($us == TRUE) {
                
            } else {
                
            }
        }

        break;
    default :
        break; 
     }

?>