<?php
session_start();
require_once '../modelo/Usuario.php';
require_once '../DAO/UsuarioDAO.php';

if (empty($_POST['nome']) || empty($_POST['usuario']) || empty($_POST['senha'])) {
    header('Location: ../Visao/cadastro.php');
    exit();
}

$nome = trim($_POST['nome']);
$usuario = trim($_POST['usuario']);
$senha = trim($_POST['senha']);

$usuario = new ClassUsuario($nome, $usuario, $senha);
$usuarioDAO = new ClassUsuarioDAO();

if ($usuarioDAO->existeUsuario($usuario)) {
    $_SESSION['usuario_existe'] = true;
    header('Location: ../Visao/cadastro.php');
    exit();
}

if ($usuarioDAO->cadastrarUsuario($usuarioObj)) {
    $_SESSION['status_cadastro'] = true;
}

header('Location: ../Visao/cadastro.php');
exit();
?>
