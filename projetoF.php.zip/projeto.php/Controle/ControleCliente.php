<?php
   require_once '../Modelo/ClassCliente.php';
   require_once '../Modelo/DAO/ClassClienteDao.php';

   $id = @$_POST['idex'];
   $nome = @$_POSt['nome'];
   $email = @$_POST ['email'];
   $telefone = @$_POST['telefone'];
   $cpf = @$_POST['cpf'];
   $acao = $_GET['ACAO'];


   $novoCliente = new ClassCliente();
   $novoCliente->setClienteId($id);
   $novoCliente->setNome($nome);
   $novoCliente->setEmail($email);
   $novoCliente->setTelefone($telefone);
   $novoCliente->setCpf($cpf);
  
   $ClassClienteDAO = new ClassUsuarioDAO();
     switch($acao){
        case "cadastrarCliente":
            $usuario = $ClassClienteDAO->cadastrarCliente($novoCliente);
           if($usuario >=1){
             
           }else{

           }
        break;

        case "alterarCliente":
            $usuario = $ClassClienteDAO->alterarCliente($novoCliente);
            if($usuario ==1){

            }else{

            }
            break;

        case "excluirCliente":
            if (isset($_GET['idex'])) {
            $clienteId = $_GET['idex'];
            $classClienteDAO = new ClassClienteDAO();
            $us = $classClienteDAO->excluirCliente($clienteId);
            if ($us == TRUE) {
                
            } else {
                
            }
        }

        break;
    default :
        break; 
     }

?>