<?php
session_start();
require_once '../modelo/Usuario.php';
require_once '../DAO/UsuarioDAO.php';

if (empty($_POST['usuario']) || empty($_POST['senha'])) {
    header('Location: ../Visao/index.php');
    exit();
}

$usuario = new ClassUsuario($_POST['usuario'], $_POST['senha']);
$usuarioDAO = new ClassUsuarioDAO();

$dados = $usuarioDAO->autenticar($usuario);

if ($dados) {
    $_SESSION['nome'] = $dados['nome'];
    header('Location: ../Visao/painel.php');
    exit();
} else {
    $_SESSION['nao_autenticado'] = true;
    header('Location: ../Visao/index.php');
    exit();
}
?>
