<?php
session_start();
if (!isset($_SESSION['nome'])) {
    header('Location: ../Visao/index.php');
    exit();
}
?>
