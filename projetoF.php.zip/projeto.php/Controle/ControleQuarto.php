<?php
require_once '../modelo/ClassQuarto.php';
require_once '../modelo/DAO/ClassQuartoDAO.php';

$idQuarto = @$_POST['idex'];
$tipoDeQuarto = @$_POST['tdq'];
$capacidade = @$_POST['capacidade'];
$precoPorNoite = @$_POST['ppn'];
$acao = $_GET['ACAO'];

$novoQuarto = new ClassQuarto();
$novoQuarto->setQuartoId($idQuarto);
$novoQuarto->setTipoDeQuarto($tipoDeQuarto);
$novoQuarto->setCapacidade($capacidade);
$novoQuarto->setPrecoPorNoite($precoPorNoite);

$quartoDAO = new ClassQuartoDAO();

switch($acao){
    case "cadastrarQuarto":
         $quarto = $quartoDAO->cadastrarQuarto($novoQuarto);
           if($quarto >=1){
             
           }else{

           }
        break;
    case "alterarQuarto":
        $quarto = $quartoDAO->alterarQuarto($novoQuarto);
        if($quarto==1){

        }else{

        }
        break;
    case "excluirQuarto":
          if (isset($_GET['idex'])) {
            $idQuarto = $_GET['idex'];
            $classQuartoDAO = new ClassClienteDAO();
            $us = $classQuartoDAO->excluirQuarto($idQuarto);
            if ($us == TRUE) {
                
            } else {
                
            }
        }
      break;
      default :
      break;
}
?>